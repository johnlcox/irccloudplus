irccloud+
=========

What is irccloud+
---

irccloud+ is  Google Chrome Extension that provides some additional features to irccloud.com

What Features?
----
Some of the features provided are:
* Audible alert for pop-up notification
* Per-channel notification trigger
* One click access to irccloud.com
* Secure server connection support

Download
---
You can download & install the extension from: https://chrome.google.com/webstore/detail/eofjjdglfohphljaddhgmoiimdjlcidd
