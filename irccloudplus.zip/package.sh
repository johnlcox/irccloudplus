#!/bin/bash
zip irccloudplus *  -x \.git -x \*.zip
